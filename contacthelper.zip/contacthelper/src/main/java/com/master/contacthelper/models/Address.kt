package com.master.contacthelper.models

data class Address(var value: String, var type: Int, var label: String)
