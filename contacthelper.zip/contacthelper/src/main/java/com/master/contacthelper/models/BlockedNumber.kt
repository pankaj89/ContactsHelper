package com.master.contacthelper.models

data class BlockedNumber(val id: Long, val number: String, val normalizedNumber: String)
