package com.master.contacthelper.models

data class Event(var value: String, var type: Int)
