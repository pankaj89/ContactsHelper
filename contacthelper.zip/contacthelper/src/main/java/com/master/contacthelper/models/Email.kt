package com.master.contacthelper.models

data class Email(var value: String, var type: Int, var label: String)
